package com.roshanmath.app

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private val Navy = Color(0xFF123B70)
private val Blue = Color(0xFF1769C2)
private val Gold = Color(0xFFFFC928)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoshanMathScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoshanMathScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) question = spoken
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Gold)) {
        Scaffold(containerColor = Color(0xFFF3F7FF), topBar = {
            TopAppBar(title = {
                Column {
                    Text("Roshan Math", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("ଆସ ଗଣିତ ଶିଖିବା • ସହଜ ଓଡ଼ିଆରେ", color = Color(0xFFE0ECFF), fontSize = 12.sp)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy))
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🧮", fontSize = 42.sp)
                        Text("ଆଜି କ'ଣ ଶିଖିବା?", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("ଯେକୌଣସି ଗଣିତ ପ୍ରଶ୍ନ ପଚାରନ୍ତୁ", color = Color(0xFFDCEAFF), fontSize = 14.sp)
                        Text("କ୍ଲାସ୍ ବାଛିବା ଦରକାର ନାହିଁ", color = Gold, fontWeight = FontWeight.SemiBold)
                    }
                }
                Text("ଆପଣଙ୍କ ପ୍ରଶ୍ନ ଲେଖନ୍ତୁ କିମ୍ବା ମାଇକ୍ ଦବାନ୍ତୁ", color = Navy, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = question, onValueChange = { question = it }, modifier = Modifier.fillMaxWidth(), minLines = 2, placeholder = { Text("ଉଦାହରଣ: ୨୫ × ୧୨ କେତେ?") }, shape = RoundedCornerShape(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "or-IN")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "ଓଡ଼ିଆରେ ଗଣିତ ପ୍ରଶ୍ନ କୁହନ୍ତୁ")
                        }
                        speech.launch(intent)
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                        Icon(Icons.Default.Mic, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("ମାଇକ୍")
                    }
                    Button(onClick = {
                        if (question.isNotBlank()) {
                            busy = true; error = ""; answer = ""
                            scope.launch {
                                try { answer = askRoshanMath(question) }
                                catch (e: Exception) { error = "ଉତ୍ତର ଆଣିହେଲା ନାହିଁ। ଇଣ୍ଟରନେଟ୍ ଓ ସର୍ଭର ସେଟିଂ ଯାଞ୍ଚ କରନ୍ତୁ।" }
                                finally { busy = false }
                            }
                        }
                    }, modifier = Modifier.weight(1f), enabled = !busy && question.isNotBlank()) {
                        Icon(Icons.Default.Send, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("ସମାଧାନ")
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (error.isNotBlank()) Text(error, color = Color(0xFFB3261E))
                if (answer.isNotBlank()) {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("📘 ସହଜ ଭାଷାରେ ସମାଧାନ", color = Navy, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text(answer, color = Color(0xFF202B3C), fontSize = 16.sp, lineHeight = 25.sp)
                        }
                    }
                }
                Text("ପ୍ରତ୍ୟେକ ଉତ୍ତରରେ: ପଦକ୍ଷେପ + ୩ଟି ଉଦାହରଣ + ଉତ୍ତର", color = Navy, fontSize = 13.sp)
                Text("Roshan Math • ଛୋଟ ପିଲାଙ୍କ ପାଇଁ ସହଜ ଗଣିତ", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

private suspend fun askRoshanMath(question: String): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    // Configure your own secure backend URL here. Never put an AI secret key in the Android app.
    val endpoint = BuildConfigValues.API_BASE_URL.trimEnd('/') + "/solve"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    try {
        val body = JSONObject().put("question", question).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (connection.responseCode !in 200..299) error("Server error: ${connection.responseCode}")
        JSONObject(response).optString("answer", "ଉତ୍ତର ମିଳିଲା ନାହିଁ।")
    } finally { connection.disconnect() }
}

private object BuildConfigValues {
    // Replace with your deployed HTTPS backend URL before building the release APK.
    const val API_BASE_URL = "https://YOUR-BACKEND-DOMAIN.example"
}
