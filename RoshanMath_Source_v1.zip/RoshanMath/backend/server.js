// Roshan Math secure AI backend (Node.js 20+). Keep OPENAI_API_KEY on the server only.
import express from 'express';

const app = express();
app.use(express.json({ limit: '1mb' }));

app.post('/solve', async (req, res) => {
  const question = String(req.body?.question || '').trim();
  if (!question) return res.status(400).json({ error: 'Question is required' });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'AI service is not configured' });

  const instructions = `You are Roshan Math, a patient mathematics teacher for children studying roughly grades 3 through 10. Solve the user's math question accurately. Reply entirely in simple, natural Odia (ଓଡ଼ିଆ), using Odia numerals where helpful but keep equations readable. Do not ask the child to choose a class. Adapt the explanation to the apparent difficulty of the question. Structure every answer with: (1) ପ୍ରଶ୍ନ (restate), (2) ସହଜ ଭାବେ ବୁଝିବା (plain-language intuition), (3) ପଦକ୍ଷେପରେ ସମାଧାନ (numbered steps), (4) ଉତ୍ତର (clearly state final answer), (5) ଆହୁରି ୩ଟି ସହଜ ଉଦାହରଣ (three similar examples, each with its answer and a short explanation). If the question is ambiguous, state the assumption simply. For non-math questions, politely say this app is for mathematics. Never fabricate a result; verify arithmetic before responding. Keep the language child-friendly and concise.`;

  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', instructions, input: question })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: 'AI provider error', details: data.error?.message || 'Unknown error' });
    const answer = (data.output || []).flatMap(item => item.content || []).filter(c => c.type === 'output_text').map(c => c.text).join('\n').trim();
    return res.json({ answer: answer || 'ଦୟାକରି ପ୍ରଶ୍ନଟି ଆଉଥରେ ପଚାରନ୍ତୁ।' });
  } catch (err) {
    return res.status(500).json({ error: 'Server error' });
  }
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`Roshan Math API listening on ${port}`));
