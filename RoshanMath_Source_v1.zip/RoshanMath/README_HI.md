# Roshan Math — Android starter project

यह पहला Android Studio source project है। इसमें:
- कोई class चुनने की जरूरत नहीं
- ओड़िया में लिखकर सवाल पूछना
- ओड़िया speech recognition (डिवाइस/Google speech service support पर निर्भर)
- AI से सरल ओड़िया में step-by-step समाधान और 3 उदाहरण
- Roshan Math की चुनी हुई बच्चों वाली icon artwork

## जरूरी स्थिति
यह **source project / शुरुआती prototype** है, तैयार APK नहीं। इस execution environment में Android SDK/Gradle build tool उपलब्ध नहीं था, इसलिए APK compile और device-test नहीं किया गया। AI answers चलाने के लिए backend deploy करना और उसका HTTPS URL app source में डालना जरूरी है।

## Backend setup
1. Node.js 20+ वाले server पर `backend/` folder copy करें।
2. `npm install` चलाएँ।
3. Server environment में `OPENAI_API_KEY` और जरूरत हो तो `OPENAI_MODEL` सेट करें। API key Android app में न डालें।
4. `npm start` से server चलाएँ और HTTPS पर `/solve` endpoint उपलब्ध कराएँ।
5. `MainActivity.kt` में `BuildConfigValues.API_BASE_URL` को अपने backend HTTPS URL से बदलें।

## APK बनाना
1. Android Studio में इस folder को खोलें।
2. Gradle sync पूरा होने दें (Android SDK 35 install होना चाहिए)।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. Microphone और Odia speech recognition को असली Android फोन पर जांचें; कुछ फोन में Odia voice input के लिए Google app/speech service और Odia language support जरूरी है।

## आगे के काम
- generated app icon को Android mipmap adaptive icon sizes में export करना
- chat history local storage में save करना
- camera/image question support जोड़ना
- speech output (Odia text-to-speech) जोड़ना
- rate limiting, authentication, abuse protection और server-side logging जोड़ना
- school syllabus/verified math tests के साथ quality assurance करना
